Painel Web
==========

Novo SGA Painel escrito em HTML5 e Javascript.

Compatível com versões a partir da 1.0.0

### TODO
- [ ] Update to Novo SGA 2.0
- [ ] Remove specific code for Albert Sabin Hospital

