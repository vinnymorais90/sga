Sounds by freesound.org


doorbell-bingbong.wav
http://www.freesound.org/people/Benboncan/sounds/76925/

toydoorbell.wav
http://www.freesound.org/people/AMPUL/sounds/29726/

ding-dong.wav
http://www.freesound.org/people/2887679652/sounds/171755/

quito-mariscal-sucre.wav
http://www.freesound.org/people/milton./sounds/81085/

infobleep.wav
http://www.freesound.org/people/Divinux/sounds/198414/

airport-bingbong.wav
http://www.freesound.org/people/Benboncan/sounds/93646/