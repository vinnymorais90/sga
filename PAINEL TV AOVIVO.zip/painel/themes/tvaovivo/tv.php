<html lang="en">
    <head>
        <meta charset=utf-8/>
    </head>
    <body>
        <div id='player'>
            <video width="100%" height="100%" src="http://gerador.starbr.com/player/#http://apk26.futeboltvgratis.com/live/7/playlist.m3u8" controls autoplay>
            </video>
        </div>
    </body>
</html>